//
//  Utils.cpp
//  
//
//  Created by cami on 7/19/18.
//
//

#include "Utils.hpp"


Utils::Utils(){
    
}

Utils::~Utils(){
    
}

//TODO
void Utils::computeFrequency(){
    
    
}
//TODO
void Utils::huffEncode(){
    
    
}
//TODO
void Utils::huffDecode(){
    
    
}
