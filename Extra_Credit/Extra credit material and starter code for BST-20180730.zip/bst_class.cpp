//
//  bst_class.cpp
//
//
//  Created by cami on 6/26/18.
//
// This is a starter which implements some features that a tree can have!

// For Extra Credit complete the remaining funtions in the bst_class.h and all the TO DO that you find
// in this file.

// Where to find the TO DOs?
// 1) inside BST()
// 2) inside ~BST()
// 3) inside addNode()
// 4) check out .h file and you'll find the remaining TO DOs.

#include "bst_class.h"


BST::BST() {
    
    // !! TO DO: what can we do here?
}

BST::~BST() {
    
    // !! TO DO: what can we do here?
}

Node* BST::createNode(int itemToAdd, Node* parentNode, Node* leftChild, Node* rightChild) {
    Node* newNode = new Node;
    newNode->key = itemToAdd;
    newNode->parent = parentNode;
    newNode->left = leftChild;
    newNode->right = rightChild;
    
    return newNode;
}


bool BST::addNode(int value) {
    
    Node* tmpNode = root;
    Node* curParent = nullptr;
    
    // Traverse the tree and find correct place
    while(tmpNode != nullptr)
    {
        // Set the "possible future" caring Parent
        curParent = tmpNode;
        if(value > tmpNode->key)
        {
            tmpNode = tmpNode->right;
        }
        else
        {
            tmpNode = tmpNode->left;
        }
        
        // !! TO DO: What if the value is already in the tree?
        
    }
    
    // !! TO DO: it is not great practice to print out stuff in methods that have other purposes,
    //           however, for debugging and checks it is usefull (especially in dev enviornments).
    //           Print out meaningful information after "meaningful" actions are performed.
    
    // When found the right parent to add the new child to, add the new child either to the left or the right
    
    // Wait wait wait...... what if null?
    if (curParent == nullptr) {
        root =  createNode(value, nullptr, nullptr, nullptr);
    }
    
    // Ok phew it's not null, now what? should it go right or left?
    else if (value < curParent->key)
    {
        curParent->left =  createNode(value, curParent, nullptr, nullptr)
    }
    
    else
    {
        curParent->right = createNode(value, curParent, nullptr, nullptr)
    }
    
}


// Now we dive into hard core good recursion, understand it by creating simple trees
void BST::printNodesInOrder(Node* nodeToPrint) {
    
    if(nodeToPrint) {
        
        if(nodeToPrint->left)
            printInOrder(nodeToPrint->left);
        
        cout<<nodeToPrint->key<<endl;
        
        if(nodeToPrint->right)
            printInOrder(nodeToPrint->right);
        
    }
    
    return;
}


void BST::printNodesPostOrder(Node* nodeToPrint) {
    
    if(nodeToPrint) {
        
        
        cout<<nodeToPrint->key<<endl;
        
        if(nodeToPrint->left)
            printInOrder(nodeToPrint->left);
        
        
        if(nodeToPrint->right)
            printInOrder(nodeToPrint->right);
        
    }
    
    return;
}

void BST::printNodesPreOrder(Node* nodeToPrint) {
    
    if(nodeToPrint) {
        
        if(nodeToPrint->left)
            printInOrder(nodeToPrint->left);
        
        
        if(nodeToPrint->right)
            printInOrder(nodeToPrint->right);
        
        cout<<nodeToPrint->key<<endl;
        
    }
    
    return;
}

Node* BST::search(Node* root, int value) {
    
    // Sanity check
    
    if(root) {
        
        if(root->key > value && root->left)
            search(root->left, value);
        
        else if(root->key < value && root->right)
            search(root->right, value);
        
        else if(root->key == value)
            return root;
        else
            return NULL;
    }
    
    
}

Node* BST::deleteNode(int value) {
    
    
    // Sanity check
    
    if(root) {
        // DO GOOD STUFF!!
        
        Node* nodeToDelete = search(root, value);
        
        if(nodeToDelete) {
            
            // DO I have children???
            
            // If not what?
            if (!nodeToDelete->left && !nodeToDelete->right) {
                
                nodeToDelete->parent = NULL;
                cout<<"Leaf node deleted"<<endl;
                delete nodeToDelete;
            }
            
            // If yes how many? andddddd, do they have children as well? how do you deal with that?
            
                // 1?
            
                    // Is it left?
            
            
                    // Is it right?
            
            // 2?
            
            
        }
        
    }
    
    return root;
    
}



bool addNodeRecursive(int){
    
    // TO DO: add helper functions if you need them
}

bool isBSTValid() {
    
    // TO DO: implementation and comment on why we don't need to pass anything to this method
    
}

int getBSTheight() {
    
    // TO DO: implementation and comment on why we don't need to pass anything to this method
}

